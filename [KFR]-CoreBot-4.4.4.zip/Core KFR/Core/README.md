-------------------

      Corebot

-------------------

By using Corebot, you agree to our terms and conditions, EULA, refund policy, and redistribution policy.

All legal information can be found here: https://docs.corebot.dev/legal

If you have any questions, please contact us by emailing legal@corebot.dev, or join our Discord server (https://discord.corebot.dev/).

-------------------

Important Links:

Corebot Documentation: https://docs.corebot.dev/
Discord Support Server: https://discord.corebot.dev/
Legal Information: https://docs.corebot.dev/legal
Corebot Addons: https://docs.corebot.dev/addons
List Of Features: https://features.corebot.dev/

-------------------